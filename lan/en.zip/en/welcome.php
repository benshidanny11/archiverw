<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archive :: welcome</title>

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

    <link href="./assets/styles/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="./assets/styles/archive.css">
    <link href="./assets/styles/main.css" rel="stylesheet" />

    <link href="assets/styles/main.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/styles/welcome.css">

</head>

<body class="body-welcome">


    <div class="container-welcome">

        <div class="row">
            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Inzego z'ibanze</h5>
                    </div>
                    <div class="card-body">

                        <p class="card-text">Reba uko inzego z'ibanze zagiye zihinduka kuva 1960 kugera 2020, n'uko abayobozi bagiye basimburana.</p>
                        <a href="redirect.php" class="btn btn-primary"> Komeza</a>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <!-- <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Inzego bwite za leta</h5>
                    </div>
                    <div class="card-body">

                        <p class="card-text">Reba uko inzego bwite za leta zagiye zihinduka kuva 1960 kugera 2020, n'uko abayobozi bagiye basimburana.</p>

                        <a href="#" class=" btn btn-primary ">Komeza</a>
                    </div>
                </div> -->
            </div>
        </div>
    </div>

</body>

</html>