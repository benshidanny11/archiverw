<?php 
 session_start();
 $_SESSION['welcomevisited'] = 'yes';
 header('Location: index.php');
?>