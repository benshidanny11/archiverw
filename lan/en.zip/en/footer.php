<div class="martop5"></div>
<footer class="page-footer font-small blue pt-4 alert-light">
  <div class="container-fluid text-center text-md-left">
    <div class="row">
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <div class="footer-copyright text-center py-3">© <script>document.write(new Date().getFullYear())</script> Copyright  &nbsp; <a href="index.php">ARCHIVE</a></div>


      </div>
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Links -->
        <h5 class="text-uppercase">Useful links</h5>

        <ul class="list-unstyled d-flex">
        
          <li class="linkitem1">
            <a href="login.php">Staff portal</a>
          </li>

          <li class="linkitem">
            <a href="welcome.php">Back to welcome</a>
          </li>

        </ul>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3">



      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>

  <!-- Copyright -->

</footer>
<!-- Footer -->